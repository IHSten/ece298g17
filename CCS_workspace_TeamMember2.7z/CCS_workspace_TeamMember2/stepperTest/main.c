#include "main.h"
#include "driverlib/driverlib.h"
#include "hal_LCD.h"
#include <msp430.h>
#include "keypad.h"

/*
 * This project contains some code samples that may be useful.
 *
 */

// 8.0
#define STEP1_P1 (0x0001)
// 2.7
#define STEP1_P2 (0x0080)
// 8.2
#define STEP1_P3 (0x0004)
// 8.3
#define STEP1_P4 (0x0008)



//KEYPAD
#define COL_PORT 5
#define ROW_PORT 1

#define COL1_PIN GPIO_PIN0
#define COL2_PIN GPIO_PIN2
#define COL3_PIN GPIO_PIN3
#define ROW1_PIN GPIO_PIN3
#define ROW2_PIN GPIO_PIN4
#define ROW3_PIN GPIO_PIN6
#define ROW4_PIN GPIO_PIN7




char ADCState = 0; //Busy state of the ADC
int16_t ADCResult = 0; //Storage for the ADC conversion result
const int steps = 4096;
const fullRotation = 2048;
const int Direction = 1;

int setDirection(int i){
    if(Direction == 1){i++;}
    if(Direction == 0){i--;}
    if(i>7){i=0;}
    if(i<0){i=7;}
    return i;

}

void step(int tostep){
    int i = 0;
    int x = 0;
  for (x; x < tostep;x++){
      switch(i){
         case 0:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P3);
             GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P4);
         break;
         case 1:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1);
             GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P3|STEP1_P4);
         break;
         case 2:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P4);
             GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P3);
         break;
         case 3:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P4);
             GPIO_setOutputHighOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P3);
         break;
         case 4:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P3|STEP1_P4);
             GPIO_setOutputHighOnPin(GPIO_PORT_P2, STEP1_P2);
         break;
         case 5:
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P1);
             GPIO_setOutputHighOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P3|STEP1_P4);
         break;
            case 6:
            GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P1);
            GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
            GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P3|STEP1_P4);
         break;
         case 7:
             GPIO_setOutputHighOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P4);
             GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P3);
         break;
         default:
             GPIO_setOutputLowOnPin(GPIO_PORT_P8, STEP1_P1|STEP1_P3|STEP1_P4);
             GPIO_setOutputLowOnPin(GPIO_PORT_P2, STEP1_P2);
         break;
      }
      i = setDirection(i);
      _delay_cycles(1000);
  }

}


int rowPins[4] = {GPIO_PIN3,   GPIO_PIN4,  GPIO_PIN6,  GPIO_PIN7};
int colPins[3] = {GPIO_PIN0,   GPIO_PIN2,  GPIO_PIN3};

int values[4][3] = {{'1','2','3'}, {'4','5','6'} , {'7','8','9'} , { '*',   '0',  '#'}};

int main(void)
{
    //Stop watchdog timer unless you plan on using it
    WDT_A_hold(WDT_A_BASE);

    // Initializations - see functions for more detail
    Init_GPIO();    //Sets all pins to output low as a default
    Init_UART();
    Init_LCD();

    //All done initializations - turn interrupts back on.
    __enable_interrupt();
    //showChar('a', 20);
    //GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN3);
    //GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P5, GPIO_PIN3);
    keypad_setup(4, 3, rowPins, colPins, values);
    //              showChar(48, 4);
  while(1){
      int key = keypad_read();
      keypad_setup(4, 3, rowPins, colPins, values);
   showChar(key, 4);
//      //clearLCD();
//      //__delay_cycles(200000);
   }
   /*
     * The MSP430 MCUs have a variety of low power modes. They can be almost
     * completely off and turn back on only when an interrupt occurs. You can
     * look up the power modes in the Family User Guide under the Power Management
     * Module (PMM) section. You can see the available API calls in the DriverLib
     * user guide, or see "pmm.h" in the driverlib directory. Unless you
     * purposefully want to play with the power modes, just leave this command in.
     */
    PMM_unlockLPM5(); //Disable the GPIO power-on default high-impedance mode to activate previously configured port settings

    // step(4096);



	//return 0;
}

void Init_GPIO(void)
{
    // Set all GPIO pins to output low to prevent floating input and reduce power consumption
    GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P3, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P4, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P5, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P6, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P7, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setOutputLowOnPin(GPIO_PORT_P8, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);

    GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P2, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P3, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P4, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P5, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P6, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P7, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);
    GPIO_setAsOutputPin(GPIO_PORT_P8, GPIO_PIN0|GPIO_PIN1|GPIO_PIN2|GPIO_PIN3|GPIO_PIN4|GPIO_PIN5|GPIO_PIN6|GPIO_PIN7);

    //Set LaunchPad switches as inputs - they are active low, meaning '1' until pressed
    GPIO_setAsInputPinWithPullUpResistor(SW1_PORT, SW1_PIN);
    GPIO_setAsInputPinWithPullUpResistor(SW2_PORT, SW2_PIN);

    //Set LED1 and LED2 as outputs
    //GPIO_setAsOutputPin(LED1_PORT, LED1_PIN); //Comment if using UART
    GPIO_setAsOutputPin(LED2_PORT, LED2_PIN);
}

/* EUSCI A0 UART ISR - Echoes data back to PC host */
#pragma vector=USCI_A0_VECTOR
__interrupt
void EUSCIA0_ISR(void)
{
    uint8_t RxStatus = EUSCI_A_UART_getInterruptStatus(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT_FLAG);

    EUSCI_A_UART_clearInterrupt(EUSCI_A0_BASE, RxStatus);
    displayScrollText("TESTING");
    if (RxStatus)
    {
        displayScrollText("TESTING");
        //displayScrollText((char*)EUSCI_A_UART_receiveData(EUSCI_A0_BASE));
        EUSCI_A_UART_transmitData(EUSCI_A0_BASE, EUSCI_A_UART_receiveData(EUSCI_A0_BASE));
    }
}

/* UART Initialization */
void Init_UART(void)
{
    /* UART: It configures P1.0 and P1.1 to be connected internally to the
     * eSCSI module, which is a serial communications module, and places it
     * in UART mode. This let's you communicate with the PC via a software
     * COM port over the USB cable. You can use a console program, like PuTTY,
     * to type to your LaunchPad. The code in this sample just echos back
     * whatever character was received.
     */

    //Configure UART pins, which maps them to a COM port over the USB cable
    //Set P1.0 and P1.1 as Secondary Module Function Input.
    GPIO_setAsPeripheralModuleFunctionInputPin(GPIO_PORT_P1, GPIO_PIN1, GPIO_PRIMARY_MODULE_FUNCTION);
    GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P1, GPIO_PIN0, GPIO_PRIMARY_MODULE_FUNCTION);

    /*
     * UART Configuration Parameter. These are the configuration parameters to
     * make the eUSCI A UART module to operate with a 9600 baud rate. These
     * values were calculated using the online calculator that TI provides at:
     * http://software-dl.ti.com/msp430/msp430_public_sw/mcu/msp430/MSP430BaudRateConverter/index.html
     */

    //SMCLK = 1MHz, Baudrate = 9600
    //UCBRx = 6, UCBRFx = 8, UCBRSx = 17, UCOS16 = 1
    EUSCI_A_UART_initParam param = {0};
        param.selectClockSource = EUSCI_A_UART_CLOCKSOURCE_SMCLK;
        param.clockPrescalar    = 6;
        param.firstModReg       = 8;
        param.secondModReg      = 17;
        param.parity            = EUSCI_A_UART_NO_PARITY;
        param.msborLsbFirst     = EUSCI_A_UART_LSB_FIRST;
        param.numberofStopBits  = EUSCI_A_UART_ONE_STOP_BIT;
        param.uartMode          = EUSCI_A_UART_MODE;
        param.overSampling      = 1;

    if(STATUS_FAIL == EUSCI_A_UART_init(EUSCI_A0_BASE, &param))
    {
        return;
    }

    EUSCI_A_UART_enable(EUSCI_A0_BASE);

    EUSCI_A_UART_clearInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);

    // Enable EUSCI_A0 RX interrupt
    EUSCI_A_UART_enableInterrupt(EUSCI_A0_BASE, EUSCI_A_UART_RECEIVE_INTERRUPT);
}
