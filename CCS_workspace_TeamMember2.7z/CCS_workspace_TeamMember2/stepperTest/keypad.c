/*
  @file keypad.c
 
  @author Andy Lindsay
 
  @version v1.1.6
 
  @copyright
  Copyright (C) Parallax, Inc. 2017. All Rights MIT Licensed.
 
  @brief keypad library source. 
*/

#include "keypad.h"
#include "driverlib/driverlib.h"
#include "hal_LCD.h"


static int rows;
static int cols;
static int *rowIo;
static int *colIo;
int btnVals[4][3] = {0};


void keypad_setup(int rowCount, int columnCount, int *rowPinCons, int *columnPinCons, int buttonValues[4][3])
{
    int col, row;
  rows = rowCount;
  cols = columnCount;
  rowIo = rowPinCons;
  colIo = columnPinCons;
  for(col = 0; col < cols; col++ )
  {
      for(row = 0; row < rows; row++)
      {
          btnVals[row][col] = buttonValues[row][col];
      }
  }
  for(row = 0; row < rows; row++)
  {
      GPIO_setAsOutputPin(GPIO_PORT_P1, rowIo[row]);
      GPIO_setOutputLowOnPin(GPIO_PORT_P1, rowIo[row]);

  }      
  for(col = 0; col < cols; col++)
  {
      //GPIO_setAsOutputPin(GPIO_PORT_P5, colIo[col]);
     // GPIO_setOutputHighOnPin(GPIO_PORT_P5, colIo[col]);
      //GPIO_setAsInputPin(GPIO_PORT_P5, colIo[col]);
      GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P5, colIo[col]);

  }
  //showChar('a', 4);
     __delay_cycles(200000);
} 





int keypad_read(void)
{
  return keypad_readFrom(-1);
}  


int keypad_readFrom(int button)
{
  int state = 0, n = 0;
  int row, col, rowStart, colStart;
  int elements = 12;

  rowStart = 0;
  colStart = 0;
  if(n == elements) return -1;
  int finalCol;
  int finalRow;
  int found = 0;

  for(row = 0; row < rows; row++)
  {
      //GPIO_setAsOutputPin(GPIO_PORT_P1, rowIo[row]);
      GPIO_setOutputLowOnPin(GPIO_PORT_P1, rowIo[row]);

  }
  for(col = 0; col < cols; col++) {
      //GPIO_setAsOutputPin(GPIO_PORT_P5, colIo[col]);
      //GPIO_setOutputHighOnPin(GPIO_PORT_P5, colIo[col]);
      GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P5, colIo[col]);

  }
  //for(row = 0; row < rows; row++) GPIO_setAsInputPin(GPIO_PORT_P1, rowIo[row]);
  for(col = colStart; col < cols && found == 0; col++ )
  {
      state = GPIO_getInputPinValue(GPIO_PORT_P5, colIo[col]);
      int new = state;
      if(state == GPIO_INPUT_PIN_LOW){
          GPIO_setAsInputPin(GPIO_PORT_P5, colIo[col]);
          for(row = rowStart; row < rows; row++){
              //GPIO_setAsOutputPin(GPIO_PORT_P1, rowIo[row]);
              GPIO_setOutputHighOnPin(GPIO_PORT_P1, rowIo[row]);
              state = GPIO_getInputPinValue(GPIO_PORT_P5, colIo[col]);
              if(state == GPIO_INPUT_PIN_HIGH){
                  finalCol = col;
                  finalRow = row;
                  found = 1;
                  return btnVals[finalRow][finalCol];
              }
          }
      }
  }

 int key = btnVals[finalRow][finalCol];
  //print("\r");
 return ' ';

}

