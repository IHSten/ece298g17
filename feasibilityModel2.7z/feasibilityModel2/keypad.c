/*
 * keypad.c
 *
 *  Created on: Nov 6, 2019
 *      Author: ai3shaik
 */
#include "main.h"
#include "keypad.h"
#include "driverlib/driverlib.h"
#include <msp430.h>

int values[4][3] = {{'1','2','3'},
              {'4','5','6'},
              {'7','8','9'},
              {'-','0','#'}};


uint8_t col[2][3] = {{GPIO_PORT_P5, GPIO_PORT_P1, GPIO_PORT_P5},
       {GPIO_PIN0, GPIO_PIN7, GPIO_PIN3}};

uint8_t row[2][4] = {{GPIO_PORT_P1, GPIO_PORT_P1, GPIO_PORT_P1, GPIO_PORT_P5},
       {GPIO_PIN6, GPIO_PIN5, GPIO_PIN4, GPIO_PIN2}};
int keypad_init(){

    GPIO_setAsInputPinWithPullDownResistor(col[0][0], col[1][0]);
    GPIO_setAsInputPinWithPullDownResistor(col[0][1], col[1][1]);
    GPIO_setAsInputPinWithPullDownResistor(col[0][2], col[1][2]);
    GPIO_setAsOutputPin(row[0][0], row[1][0]);
    GPIO_setAsOutputPin(row[0][1], row[1][1]);
    GPIO_setAsOutputPin(row[0][2], row[1][2]);
    GPIO_setAsOutputPin(row[0][3], row[1][3]);

}

int readKeypad(){
        uint8_t val = 0;
        int i;
        for(i = 0; i < 4; i++){
            GPIO_setOutputHighOnPin(row[0][i], row[1][i]);
            if(GPIO_getInputPinValue(col[0][0], col[1][0]) == GPIO_INPUT_PIN_HIGH){
                GPIO_setOutputLowOnPin(row[0][i], row[1][i]);
                return values[i][0];
            }
            else if(GPIO_getInputPinValue(col[0][1], col[1][1]) == GPIO_INPUT_PIN_HIGH){
                GPIO_setOutputLowOnPin(row[0][i], row[1][i]);
                return values[i][1];
            }
            else if(GPIO_getInputPinValue(col[0][2], col[1][2]) == GPIO_INPUT_PIN_HIGH){
                GPIO_setOutputLowOnPin(row[0][i], row[1][i]);
                return values[i][2];
            }
            GPIO_setOutputLowOnPin(row[0][i], row[1][i]);
        }
        GPIO_setOutputLowOnPin(row[0][i], row[1][i]);
        return -1;
}
