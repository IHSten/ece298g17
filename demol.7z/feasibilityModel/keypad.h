/*
 * keypad.h
 *
 *  Created on: Nov 6, 2019
 *      Author: ai3shaik
 */

#ifndef KEYPAD_H_
#define KEYPAD_H_



#endif /* KEYPAD_H_ */

//int values[4][3];
//uint8_t col[2][3];
//uint8_t row[2][4];


int keypad_init();
int readKeypad();
