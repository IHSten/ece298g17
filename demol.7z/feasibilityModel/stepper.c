#include "main.h"
#include "driverlib/driverlib.h"
#include "hal_LCD.h"
#include "keypad.h"
#include <msp430.h>
#include "stepper.h"

int stepsRemaining = 2048;
int stepper1Toggle = 0;
const fullRotation = 2048;
const int Direction = 1;
int stopX = 0;
int stopY = 0;

int stopXmotor(){
    stopX = 1;
}
int stopYmotor(){
    stopY = 1;
}
//int contX(){
//    stopX = 0;
//}
//int contY(){
//    stopY = 0;
//}

void Init_GPIO_STEPPER(void)
{
    GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1|STEP1_P2_PIN2|STEP1_P2_PIN3);
    GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
    GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
    GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2|STEP2_P2_PIN3);

    GPIO_setAsOutputPin(STEP1_PORT2, STEP1_P2_PIN1|STEP1_P2_PIN2|STEP1_P2_PIN3);
    GPIO_setAsOutputPin(STEP1_PORT1, STEP1_P1_PIN1);
    GPIO_setAsOutputPin(STEP2_PORT1, STEP2_P1_PIN1);
    GPIO_setAsOutputPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2|STEP2_P2_PIN3);

    GPIO_selectInterruptEdge(GPIO_PORT_P2, GPIO_PIN5, GPIO_LOW_TO_HIGH_TRANSITION);
    GPIO_setAsInputPin(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_clearInterrupt(GPIO_PORT_P2, GPIO_PIN5);
    GPIO_enableInterrupt(GPIO_PORT_P2, GPIO_PIN5);

    // Configure button Y_Endstop (P1.3) interrupt
    GPIO_selectInterruptEdge(GPIO_PORT_P1, GPIO_PIN3, GPIO_LOW_TO_HIGH_TRANSITION);
    GPIO_setAsInputPin(GPIO_PORT_P1, GPIO_PIN3);
    GPIO_clearInterrupt(GPIO_PORT_P1, GPIO_PIN3);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN3);

}

int setDirection(int stepSequence, int direction){
    stepSequence+=direction;
    if(stepSequence>7){stepSequence=0;}
    if(stepSequence<0){stepSequence=7;}
    return stepSequence;

}

void step_motorx(int tostep, int direction, int *currX){
    // If direction = 1, go forward
    // If direction = -1, go backward

    int i = 0;
    int x = 0;
    int j = 0;
    for (x; x < tostep;x++){
     for(j = 0; j < 2048; j++){
         if(stopX == 0){
             switch(i){
             case 0:
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2);
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN3);
             break;
             case 1:
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN2|STEP2_P2_PIN3);
             break;
             case 2:
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN3);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2);
             break;
             case 3:
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN3);
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN2);
             break;
             case 4:
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN2|STEP2_P2_PIN3);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN1);
             break;
             case 5:
                 GPIO_setOutputHighOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN1);
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN2|STEP2_P2_PIN3);
             break;
                case 6:
                GPIO_setOutputHighOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1);
                GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN2|STEP2_P2_PIN3);
             break;
             case 7:
                 GPIO_setOutputHighOnPin(STEP2_PORT2, STEP2_P2_PIN3);
                 GPIO_setOutputHighOnPin(STEP2_PORT1, STEP2_P1_PIN1);
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2);
             break;
             default:
                 GPIO_setOutputLowOnPin(STEP2_PORT2, STEP2_P2_PIN1|STEP2_P2_PIN2|STEP2_P2_PIN3);
                 GPIO_setOutputLowOnPin(STEP2_PORT1, STEP2_P1_PIN1);
             break;
          }
            i = setDirection(i, direction);
            _delay_cycles(900);
         }
         else{
             return;
         }
     }
     if(direction == -1){
         (*currX)--;
     }
     else{
         (*currX)++;
     }
     showChar('0' + abs(*currX), 8+6*0);
     if((*currX)/abs(*currX) == -1){
         showNegative(0);
     }
     else{
         noNegative(0);
     }
  }
}

  void step_motory(int tostep, int direction, int *currY){
      int i = 0;
      int x = 0;
      int j = 0;
      for (x; x < tostep;x++){
        for(j = 0; j < 1024; j++){
            if(stopY == 0){
                switch(i){
                         case 0:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 1:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 2:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 3:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 4:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 5:
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputHighOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 6:
                            GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                            GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                            GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                            GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         case 7:
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputHighOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                         default:
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT1, STEP1_P1_PIN1);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN2);
                             GPIO_setOutputLowOnPin(STEP1_PORT2, STEP1_P2_PIN3);
                         break;
                      }
                      i = setDirection(i, direction);
                      _delay_cycles(900);
                  }
            else{
                return;
            }
        }

      if(direction == -1)
          (*currY)--;
      else
          (*currY)++;
      showChar('0' + abs(*currY), 8+10*1);
      if((*currY)/abs(*currY) == -1)
          showNegative(1);
      else
          noNegative(1);
  }
  }


  void goToCoords(int coords[5][2], int numEntered){
      int currX = 0;
      int currY = 0;
      stopX = 0;
      stopY = 0;
      int i;
      for(i = 0; i < numEntered / 2; i++){
          int stepsX = coords[i][0] - currX;
          int stepsY = coords[i][1] - currY;

          step_motorx(abs(stepsX), stepsX/abs(stepsX), &currX);
          step_motory(abs(stepsY), stepsY/abs(stepsY), &currY);
          //currX = coords[i][0];
          //currY = coords[i][1];
          stopX = 0;
          stopY = 0;

      }
      return;
  }
