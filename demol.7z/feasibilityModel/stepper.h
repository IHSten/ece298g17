#include <msp430.h>
#include "driverlib/driverlib.h"

// ORIGINAL
// 8.0
#define STEP1_P1 (0x0001)
// 2.7
#define STEP1_P2 (0x0080)
// 8.2
#define STEP1_P3 (0x0004)
// 8.3
#define STEP1_P4 (0x0008)


// 5.3, 1.7, 5.0, 5.1
#define STEP1_PORT1 1
#define STEP1_PORT2 5


#define STEP1_P1_PIN1 (0x0080)
#define STEP1_P2_PIN1 (0x0008)
#define STEP1_P2_PIN2 (0x0001)
#define STEP1_P2_PIN3 (0x0002)


// 2.7, 8.0, 8.2, 8.3
#define STEP2_PORT1 2
#define STEP2_PORT2 8

#define STEP2_P1_PIN1 (0x0080)
#define STEP2_P2_PIN1 (0x0001)
#define STEP2_P2_PIN2 (0x0004)
#define STEP2_P2_PIN3 (0x0008)


void Init_GPIO_STEPPER();
void step_motorx(int steps, int direction, int *currX);
void step_motory(int steps, int direction, int *currY);
int stopXmotor();
int stopYmotor();
void goToCoords(int coords[5][2], int numEntered);
